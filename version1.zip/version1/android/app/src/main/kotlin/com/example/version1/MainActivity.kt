package com.example.version1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
